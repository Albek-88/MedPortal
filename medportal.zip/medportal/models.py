"""Доменные классы «Медицинского портала» (задачи 2–6, 9, 10, 16–22).

Именование: методы из задания (UpdateProfile, GetAge …) записаны в стиле
Python — update_profile, get_age и т.д.
"""
from abc import ABC, abstractmethod
from datetime import date, datetime, time, timedelta
from enum import Enum


# --------------------------------------------------------------------------
# Исключения
# --------------------------------------------------------------------------
class ValidationError(ValueError):
    """Некорректные входные данные."""


class DoctorBusyError(ValidationError):
    """Врач занят на выбранное время."""


# --------------------------------------------------------------------------
# Вспомогательные функции проверки
# --------------------------------------------------------------------------
def _required(value, field):
    value = (value or "").strip() if isinstance(value, str) or value is None else value
    if value in ("", None):
        raise ValidationError(f"Поле «{field}» обязательно для заполнения")
    return value


def _to_date(value, field):
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value))
    except ValueError:
        raise ValidationError(f"Поле «{field}»: неверная дата")


def _to_number(value, field):
    try:
        return float(str(value).replace(",", "."))
    except ValueError:
        raise ValidationError(f"Поле «{field}» должно быть числом")


# --------------------------------------------------------------------------
# Перечисления (задача 20)
# --------------------------------------------------------------------------
class AppointmentStatus(Enum):
    Scheduled = "Scheduled"
    Confirmed = "Confirmed"
    Completed = "Completed"
    Cancelled = "Cancelled"

    @property
    def label(self):
        return {"Scheduled": "Запланирован", "Confirmed": "Подтверждён",
                "Completed": "Завершён", "Cancelled": "Отменён"}[self.value]


class PaymentStatus(Enum):
    Pending = "Pending"
    Paid = "Paid"
    Refunded = "Refunded"

    @property
    def label(self):
        return {"Pending": "Ожидает", "Paid": "Оплачен", "Refunded": "Возвращён"}[self.value]


# --------------------------------------------------------------------------
# Интерфейс IPayable (задача 18)
# --------------------------------------------------------------------------
class IPayable(ABC):
    @abstractmethod
    def calculate_payment(self) -> float:
        """Сумма выплаты / к оплате."""


# --------------------------------------------------------------------------
# Абстрактный класс Person (задача 16)
# --------------------------------------------------------------------------
class Person(ABC):
    def __init__(self, id, full_name, birth_date):
        self._id = id
        self.full_name = full_name
        self.birth_date = birth_date

    @property
    def id(self):
        return self._id

    @property
    def full_name(self):
        return self._full_name

    @full_name.setter
    def full_name(self, value):
        self._full_name = " ".join(_required(value, "ФИО").split())

    @property
    def birth_date(self):
        return self._birth_date

    @birth_date.setter
    def birth_date(self, value):
        d = _to_date(value, "Дата рождения")
        if d > date.today():
            raise ValidationError("Возраст не может быть отрицательным (дата рождения в будущем)")
        self._birth_date = d

    def get_age(self):
        today = date.today()
        b = self._birth_date
        return today.year - b.year - ((today.month, today.day) < (b.month, b.day))

    @abstractmethod
    def display_info(self) -> str:
        ...


# --------------------------------------------------------------------------
# Patient (задачи 2, 11, 17, 19)
# --------------------------------------------------------------------------
class Patient(Person):
    def __init__(self, id, full_name, birth_date, phone, email, address=""):
        super().__init__(id, full_name, birth_date)
        self.phone = phone
        self.email = email
        self.address = address
        # ассоциации
        self.appointments = []                # 1 пациент — 0..* приёмов
        self.record = None                    # композиция: 1 пациент — 1 медкарта
        self.tests = []
        self.prescriptions = []
        self.payments = []

    @property
    def phone(self):
        return self._phone

    @phone.setter
    def phone(self, value):
        value = _required(value, "Телефон")
        if sum(ch.isdigit() for ch in value) < 6:
            raise ValidationError("Телефон указан некорректно")
        self._phone = value

    @property
    def email(self):
        return self._email

    @email.setter
    def email(self, value):
        value = _required(value, "Email")
        if "@" not in value or "." not in value.split("@")[-1]:
            raise ValidationError("Email указан некорректно")
        self._email = value

    @property
    def address(self):
        return self._address

    @address.setter
    def address(self, value):
        self._address = (value or "").strip()

    def update_profile(self, full_name, birth_date, phone, email, address):
        self.full_name = full_name
        self.birth_date = birth_date
        self.phone = phone
        self.email = email
        self.address = address

    def display_info(self):
        return (f"Пациент #{self.id}: {self.full_name}, {self.get_age()} лет, "
                f"тел. {self.phone}, {self.email}")


# --------------------------------------------------------------------------
# Doctor (задачи 3, 7, 8, 12, 17, 18)
# --------------------------------------------------------------------------
WORK_START = time(9, 0)
WORK_END = time(18, 0)
SLOT_MINUTES = 30


def work_slots():
    """Все слоты рабочего дня: 09:00, 09:30 … 17:30."""
    slots, cur = [], datetime.combine(date.today(), WORK_START)
    end = datetime.combine(date.today(), WORK_END)
    while cur < end:
        slots.append(cur.strftime("%H:%M"))
        cur += timedelta(minutes=SLOT_MINUTES)
    return slots


class Doctor(Person, IPayable):
    EXPERIENCE_BONUS = 0.02     # +2 % к окладу за каждый год стажа
    MAX_BONUS_YEARS = 20

    def __init__(self, id, full_name, birth_date, specialization, experience,
                 cabinet_number, salary):
        super().__init__(id, full_name, birth_date)
        self.specialization = specialization
        self.experience = experience
        self.cabinet_number = cabinet_number
        self.salary = salary
        self.appointments = []     # 1 врач — 0..* приёмов
        self.department = None     # агрегация: врач живёт и без отделения

    @property
    def specialization(self):
        return self._specialization

    @specialization.setter
    def specialization(self, value):
        self._specialization = _required(value, "Специализация")

    @property
    def experience(self):
        return self._experience

    @experience.setter
    def experience(self, value):
        n = int(_to_number(value, "Стаж"))
        if n < 0:
            raise ValidationError("Стаж не может быть отрицательным")
        self._experience = n

    @property
    def cabinet_number(self):
        return self._cabinet

    @cabinet_number.setter
    def cabinet_number(self, value):
        self._cabinet = str(_required(value, "Кабинет"))

    @property
    def salary(self):
        return self._salary

    @salary.setter
    def salary(self, value):
        v = _to_number(value, "Оклад")
        if v < 0:
            raise ValidationError("Оклад не может быть отрицательным")
        self._salary = v

    def update_specialization(self, value):
        self.specialization = value

    def calculate_salary(self):
        years = min(self.experience, self.MAX_BONUS_YEARS)
        return round(self.salary * (1 + years * self.EXPERIENCE_BONUS), 2)

    def calculate_payment(self):            # IPayable
        return self.calculate_salary()

    # --- расписание (задачи 7, 8) -----------------------------------------
    def _active_at(self, dt):
        return [a for a in self.appointments
                if a.status != AppointmentStatus.Cancelled and a.date_time == dt]

    def is_doctor_available(self, dt):
        """Свободен ли врач в указанные дату и время (dt: datetime).
        Если передан date (без времени) — есть ли на этот день хоть один свободный слот."""
        if not isinstance(dt, datetime):
            return bool(self.free_slots(dt))
        return not self._active_at(dt)

    def free_slots(self, day):
        busy = {a.date_time.strftime("%H:%M") for a in self.appointments
                if a.status != AppointmentStatus.Cancelled and a.date_time.date() == day}
        return [s for s in work_slots() if s not in busy]

    def appointments_on(self, day):
        return sorted((a for a in self.appointments if a.date_time.date() == day),
                      key=lambda a: a.date_time)

    def display_info(self):
        return (f"Врач #{self.id}: {self.full_name}, {self.specialization}, "
                f"стаж {self.experience} л., каб. {self.cabinet_number}")


# --------------------------------------------------------------------------
# Department (задачи 4, 13)
# --------------------------------------------------------------------------
class Department:
    def __init__(self, id, name, floor, phone, head_doctor=None):
        self.id = id
        self.name = _required(name, "Название отделения")
        self.floor = int(_to_number(floor, "Этаж"))
        self.phone = _required(phone, "Телефон отделения")
        self.head_doctor = head_doctor
        self.doctors = []           # агрегация 1 — 0..*

    def add_doctor(self, doctor):
        if doctor in self.doctors:
            raise ValidationError("Этот врач уже работает в отделении")
        self.doctors.append(doctor)
        doctor.department = self

    def remove_doctor(self, doctor):
        if doctor not in self.doctors:
            raise ValidationError("Врача нет в этом отделении")
        self.doctors.remove(doctor)
        doctor.department = None
        if self.head_doctor is doctor:
            self.head_doctor = None

    def display_doctors(self):
        if not self.doctors:
            return ["В отделении пока нет врачей"]
        return [d.display_info() for d in self.doctors]


# --------------------------------------------------------------------------
# MedicalService (задачи 5, 19)
# --------------------------------------------------------------------------
class MedicalService:
    def __init__(self, id, name, description, price, duration):
        self.id = id
        self.name = _required(name, "Название услуги")
        self.description = (description or "").strip()
        self.price = price
        self.duration = duration

    @property
    def price(self):
        return self._price

    @price.setter
    def price(self, value):
        v = _to_number(value, "Стоимость")
        if v < 0:
            raise ValidationError("Стоимость услуги не может быть меньше нуля")
        self._price = v

    @property
    def duration(self):
        return self._duration

    @duration.setter
    def duration(self, value):
        v = int(_to_number(value, "Длительность"))
        if v <= 0:
            raise ValidationError("Длительность должна быть больше нуля")
        self._duration = v

    def calculate_price(self, quantity=1, discount_percent=0):
        if quantity < 1:
            raise ValidationError("Количество должно быть не меньше 1")
        if not 0 <= discount_percent <= 100:
            raise ValidationError("Скидка должна быть от 0 до 100 %")
        return round(self.price * quantity * (1 - discount_percent / 100), 2)

    def update_price(self, new_price):
        self.price = new_price

    def display_service(self):
        return f"{self.name} — {self.price:.2f} ₽, {self.duration} мин."


# --------------------------------------------------------------------------
# Appointment (задачи 6, 8, 12, 20)
# --------------------------------------------------------------------------
class Appointment:
    def __init__(self, id, patient, doctor, date_time, status=AppointmentStatus.Scheduled,
                 service=None):
        self.id = id
        self.patient = patient
        self.doctor = doctor
        self.date_time = date_time
        self.status = status
        self.service = service

    @property
    def appointment_date(self):
        return self.date_time.date()

    @property
    def appointment_time(self):
        return self.date_time.time()

    @classmethod
    def create_appointment(cls, patient, doctor, date_time, service=None, id=None):
        if date_time.minute % SLOT_MINUTES != 0:
            raise ValidationError("Время приёма должно быть кратно 30 минутам")
        if not (WORK_START <= date_time.time() < WORK_END):
            raise ValidationError("Приём ведётся с 09:00 до 18:00")
        if not doctor.is_doctor_available(date_time):
            raise DoctorBusyError("Врач уже занят на указанное время!")
        appt = cls(id, patient, doctor, date_time, AppointmentStatus.Scheduled, service)
        patient.appointments.append(appt)
        doctor.appointments.append(appt)
        return appt

    def confirm_appointment(self):
        if self.status != AppointmentStatus.Scheduled:
            raise ValidationError("Подтвердить можно только запланированный приём")
        self.status = AppointmentStatus.Confirmed

    def complete_appointment(self):
        if self.status not in (AppointmentStatus.Scheduled, AppointmentStatus.Confirmed):
            raise ValidationError("Завершить можно только активный приём")
        self.status = AppointmentStatus.Completed

    def cancel_appointment(self):
        if self.status not in (AppointmentStatus.Scheduled, AppointmentStatus.Confirmed):
            raise ValidationError("Отменить можно только активный приём")
        self.status = AppointmentStatus.Cancelled

    def display_appointment(self):
        return (f"Приём #{self.id}: {self.patient.full_name} → {self.doctor.full_name}, "
                f"{self.date_time:%d.%m.%Y %H:%M}, {self.status.label}")


# --------------------------------------------------------------------------
# MedicalRecord (задачи 9, 14) — композиция с Patient
# --------------------------------------------------------------------------
class MedicalRecord:
    def __init__(self, id, patient, diagnosis="", medical_history="", creation_date=None):
        self.id = id
        self.patient = patient
        self.diagnosis = diagnosis or ""
        self.medical_history = medical_history or ""
        self.creation_date = creation_date or date.today()
        patient.record = self

    def add_diagnosis(self, diagnosis):
        self.diagnosis = _required(diagnosis, "Диагноз")

    def update_history(self, text):
        text = _required(text, "Запись в историю болезни")
        line = f"[{date.today():%d.%m.%Y}] {text}"
        self.medical_history = (self.medical_history + "\n" + line).strip()

    def display_record(self):
        return (f"Карта #{self.id} ({self.patient.full_name}): "
                f"диагноз — {self.diagnosis or 'не указан'}")


# --------------------------------------------------------------------------
# MedicalTest (задача 10)
# --------------------------------------------------------------------------
class MedicalTest:
    def __init__(self, id, patient, test_name, test_date, result=""):
        self.id = id
        self.patient = patient
        self.test_name = _required(test_name, "Название анализа")
        self.test_date = _to_date(test_date, "Дата анализа")
        self.result = result or ""
        patient.tests.append(self)

    def add_result(self, result):
        if self.result:
            raise ValidationError("Результат уже внесён — используйте изменение результата")
        self.result = _required(result, "Результат")

    def update_result(self, result):
        self.result = _required(result, "Результат")

    def display_result(self):
        return f"{self.test_name} ({self.test_date:%d.%m.%Y}): {self.result or 'результата пока нет'}"


# --------------------------------------------------------------------------
# Prescription (задача 22)
# --------------------------------------------------------------------------
class Prescription:
    def __init__(self, id, patient, doctor, medication_name, dosage, duration):
        self.id = id
        self.patient = patient
        self.doctor = doctor
        self.update_prescription(medication_name, dosage, duration)
        patient.prescriptions.append(self)

    def update_prescription(self, medication_name, dosage, duration):
        self.medication_name = _required(medication_name, "Препарат")
        self.dosage = _required(dosage, "Дозировка")
        self.duration = _required(duration, "Длительность курса")

    def display_prescription(self):
        return (f"{self.medication_name}, {self.dosage}, курс: {self.duration} "
                f"(назначил {self.doctor.full_name})")


# --------------------------------------------------------------------------
# Payment (задачи 18, 21)
# --------------------------------------------------------------------------
class Payment(IPayable):
    def __init__(self, id, patient, amount, payment_date=None,
                 status=PaymentStatus.Pending, description=""):
        self.id = id
        self.patient = patient
        self.amount = amount
        self.payment_date = payment_date or datetime.now()
        self.status = status
        self.description = description or ""
        patient.payments.append(self)

    @property
    def amount(self):
        return self._amount

    @amount.setter
    def amount(self, value):
        v = _to_number(value, "Сумма")
        if v <= 0:
            raise ValidationError("Сумма оплаты должна быть больше нуля")
        self._amount = v

    def make_payment(self):
        if self.status == PaymentStatus.Paid:
            raise ValidationError("Платёж уже оплачен")
        if self.status == PaymentStatus.Refunded:
            raise ValidationError("Платёж был возвращён")
        self.status = PaymentStatus.Paid
        self.payment_date = datetime.now()

    def refund_payment(self):
        if self.status != PaymentStatus.Paid:
            raise ValidationError("Вернуть можно только оплаченный платёж")
        self.status = PaymentStatus.Refunded

    def calculate_payment(self):            # IPayable
        return self.amount if self.status == PaymentStatus.Paid else 0.0

    def display_payment(self):
        return (f"Платёж #{self.id}: {self.patient.full_name}, {self.amount:.2f} ₽, "
                f"{self.status.label}")
