# Медицинский портал (Flask + SQLite)

    pip install flask
    python app.py

Откройте http://localhost:5000 — при первом запуске создаётся portal.db с демо-данными.
Файлы: models.py (классы), portal.py (MedicalPortal, SQLite), app.py (сайт), uml.mmd (исходник UML).
