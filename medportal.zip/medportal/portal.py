"""MedicalPortal — управление данными (SQLite), поиск и статистика (задачи 23–25)."""
import os
import re
import sqlite3
from datetime import date, datetime

from models import (Appointment, AppointmentStatus, Department, Doctor, DoctorBusyError,
                    MedicalRecord, MedicalService, MedicalTest, Patient, Payment,
                    PaymentStatus, Prescription, ValidationError)

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "portal.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS patients(
  id INTEGER PRIMARY KEY AUTOINCREMENT, full_name TEXT NOT NULL, birth_date TEXT NOT NULL,
  phone TEXT NOT NULL, email TEXT NOT NULL, address TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS departments(
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, floor INTEGER NOT NULL,
  phone TEXT NOT NULL, head_doctor_id INTEGER);
CREATE TABLE IF NOT EXISTS doctors(
  id INTEGER PRIMARY KEY AUTOINCREMENT, full_name TEXT NOT NULL, birth_date TEXT NOT NULL,
  specialization TEXT NOT NULL, experience INTEGER NOT NULL, cabinet TEXT NOT NULL,
  salary REAL NOT NULL,
  department_id INTEGER REFERENCES departments(id) ON DELETE SET NULL);  -- агрегация
CREATE TABLE IF NOT EXISTS services(
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT DEFAULT '',
  price REAL NOT NULL, duration INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS appointments(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  doctor_id INTEGER NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
  service_id INTEGER REFERENCES services(id) ON DELETE SET NULL,
  date_time TEXT NOT NULL, status TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS records(                                        -- композиция
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL UNIQUE REFERENCES patients(id) ON DELETE CASCADE,
  diagnosis TEXT DEFAULT '', history TEXT DEFAULT '', created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS tests(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  name TEXT NOT NULL, test_date TEXT NOT NULL, result TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS prescriptions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  doctor_id INTEGER NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
  medication TEXT NOT NULL, dosage TEXT NOT NULL, duration TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS payments(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  amount REAL NOT NULL, payment_date TEXT NOT NULL, status TEXT NOT NULL,
  description TEXT DEFAULT '');
"""


def parse_dt(date_str, time_str):
    try:
        return datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M")
    except ValueError:
        raise ValidationError("Укажите корректные дату и время приёма")


class MedicalPortal:
    def __init__(self, path=DB_PATH):
        self.path = path
        with self._conn() as c:
            c.executescript(SCHEMA)
        self.load()

    # ------------------------------------------------------------------ БД
    def _conn(self):
        c = sqlite3.connect(self.path)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys=ON")
        return c

    def _exec(self, sql, params=()):
        c = self._conn()
        try:
            with c:
                return c.execute(sql, params).lastrowid
        finally:
            c.close()

    def load(self):
        """Собирает граф объектов из БД вместе со связями."""
        c = self._conn()
        try:
            rows = lambda t: c.execute(f"SELECT * FROM {t} ORDER BY id").fetchall()
            self.patients = {r["id"]: Patient(r["id"], r["full_name"], r["birth_date"], r["phone"],
                                              r["email"], r["address"]) for r in rows("patients")}
            self.doctors = {r["id"]: Doctor(r["id"], r["full_name"], r["birth_date"],
                                            r["specialization"], r["experience"], r["cabinet"],
                                            r["salary"]) for r in rows("doctors")}
            self.services = {r["id"]: MedicalService(r["id"], r["name"], r["description"],
                                                     r["price"], r["duration"]) for r in rows("services")}
            self.departments = {}
            for r in rows("departments"):
                self.departments[r["id"]] = Department(r["id"], r["name"], r["floor"], r["phone"],
                                                       self.doctors.get(r["head_doctor_id"]))
            for r in rows("doctors"):
                if r["department_id"] in self.departments:
                    self.departments[r["department_id"]].add_doctor(self.doctors[r["id"]])
            for r in rows("records"):
                rec = MedicalRecord(r["id"], self.patients[r["patient_id"]], r["diagnosis"],
                                    r["history"], date.fromisoformat(r["created"]))
            self.appointments = {}
            for r in rows("appointments"):
                a = Appointment(r["id"], self.patients[r["patient_id"]], self.doctors[r["doctor_id"]],
                                datetime.fromisoformat(r["date_time"]),
                                AppointmentStatus(r["status"]), self.services.get(r["service_id"]))
                a.patient.appointments.append(a)
                a.doctor.appointments.append(a)
                self.appointments[a.id] = a
            self.tests = {r["id"]: MedicalTest(r["id"], self.patients[r["patient_id"]], r["name"],
                                               r["test_date"], r["result"]) for r in rows("tests")}
            self.prescriptions = {r["id"]: Prescription(r["id"], self.patients[r["patient_id"]],
                                                        self.doctors[r["doctor_id"]], r["medication"],
                                                        r["dosage"], r["duration"])
                                  for r in rows("prescriptions")}
            self.payments = {r["id"]: Payment(r["id"], self.patients[r["patient_id"]], r["amount"],
                                              datetime.fromisoformat(r["payment_date"]),
                                              PaymentStatus(r["status"]), r["description"])
                             for r in rows("payments")}
        finally:
            c.close()

    # ------------------------------------------------------------ Пациенты
    def add_patient(self, full_name, birth_date, phone, email, address=""):
        p = Patient(None, full_name, birth_date, phone, email, address)      # проверка данных
        pid = self._exec("INSERT INTO patients(full_name,birth_date,phone,email,address) VALUES(?,?,?,?,?)",
                         (p.full_name, p.birth_date.isoformat(), p.phone, p.email, p.address))
        # композиция: медкарта создаётся вместе с пациентом
        self._exec("INSERT INTO records(patient_id,created) VALUES(?,?)", (pid, date.today().isoformat()))
        return pid

    def update_patient(self, pid, **f):
        p = self.patients[pid]
        p.update_profile(f["full_name"], f["birth_date"], f["phone"], f["email"], f["address"])
        self._exec("UPDATE patients SET full_name=?,birth_date=?,phone=?,email=?,address=? WHERE id=?",
                   (p.full_name, p.birth_date.isoformat(), p.phone, p.email, p.address, pid))

    def delete_patient(self, pid):
        """Удаление пациента каскадно удаляет его медкарту (композиция)."""
        self._exec("DELETE FROM patients WHERE id=?", (pid,))

    def search_patients(self, query):
        """Поиск по идентификатору, ФИО и номеру телефона (задача 23)."""
        q = (query or "").strip()
        if not q:
            raise ValidationError("Введите идентификатор, ФИО или телефон для поиска")
        digits = re.sub(r"\D", "", q)
        found = {}
        if q.isdigit() and int(q) in self.patients:
            found[int(q)] = self.patients[int(q)]
        for p in self.patients.values():
            if q.lower() in p.full_name.lower():
                found[p.id] = p
            if len(digits) >= 3 and digits in re.sub(r"\D", "", p.phone):
                found[p.id] = p
        return list(found.values())

    # ---------------------------------------------------------------- Врачи
    def add_doctor(self, full_name, birth_date, specialization, experience, cabinet, salary,
                   department_id=None):
        d = Doctor(None, full_name, birth_date, specialization, experience, cabinet, salary)
        return self._exec("INSERT INTO doctors(full_name,birth_date,specialization,experience,cabinet,"
                          "salary,department_id) VALUES(?,?,?,?,?,?,?)",
                          (d.full_name, d.birth_date.isoformat(), d.specialization, d.experience,
                           d.cabinet_number, d.salary, department_id or None))

    def update_specialization(self, did, value):
        d = self.doctors[did]
        d.update_specialization(value)
        self._exec("UPDATE doctors SET specialization=? WHERE id=?", (d.specialization, did))

    # ------------------------------------------------------------ Отделения
    def add_department(self, name, floor, phone, head_doctor_id=None):
        dep = Department(None, name, floor, phone)
        return self._exec("INSERT INTO departments(name,floor,phone,head_doctor_id) VALUES(?,?,?,?)",
                          (dep.name, dep.floor, dep.phone, head_doctor_id or None))

    def department_add_doctor(self, dep_id, doctor_id):
        self.departments[dep_id].add_doctor(self.doctors[doctor_id])
        self._exec("UPDATE doctors SET department_id=? WHERE id=?", (dep_id, doctor_id))

    def department_remove_doctor(self, dep_id, doctor_id):
        dep = self.departments[dep_id]
        dep.remove_doctor(self.doctors[doctor_id])
        self._exec("UPDATE doctors SET department_id=NULL WHERE id=?", (doctor_id,))
        self._exec("UPDATE departments SET head_doctor_id=? WHERE id=?",
                   (dep.head_doctor.id if dep.head_doctor else None, dep_id))

    def set_head_doctor(self, dep_id, doctor_id):
        dep, doc = self.departments[dep_id], self.doctors[doctor_id]
        if doc not in dep.doctors:
            raise ValidationError("Заведующим может быть только врач этого отделения")
        self._exec("UPDATE departments SET head_doctor_id=? WHERE id=?", (doctor_id, dep_id))

    # --------------------------------------------------------------- Услуги
    def add_service(self, name, description, price, duration):
        s = MedicalService(None, name, description, price, duration)
        return self._exec("INSERT INTO services(name,description,price,duration) VALUES(?,?,?,?)",
                          (s.name, s.description, s.price, s.duration))

    def update_service_price(self, sid, price):
        s = self.services[sid]
        s.update_price(price)
        self._exec("UPDATE services SET price=? WHERE id=?", (s.price, sid))

    # --------------------------------------------------------------- Приёмы
    def create_appointment(self, patient_id, doctor_id, date_str, time_str, service_id=None):
        dt = parse_dt(date_str, time_str)
        a = Appointment.create_appointment(self.patients[patient_id], self.doctors[doctor_id], dt,
                                           self.services.get(service_id))
        return self._exec("INSERT INTO appointments(patient_id,doctor_id,service_id,date_time,status)"
                          " VALUES(?,?,?,?,?)",
                          (patient_id, doctor_id, service_id, dt.isoformat(sep=" ", timespec="minutes"),
                           a.status.value))

    def change_appointment(self, aid, action):
        a = self.appointments[aid]
        getattr(a, f"{action}_appointment")()
        self._exec("UPDATE appointments SET status=? WHERE id=?", (a.status.value, aid))

    # --------------------------------------------------- Медкарта и анализы
    def update_record(self, pid, diagnosis=None, history_note=None):
        rec = self.patients[pid].record
        if diagnosis:
            rec.add_diagnosis(diagnosis)
        if history_note:
            rec.update_history(history_note)
        self._exec("UPDATE records SET diagnosis=?, history=? WHERE patient_id=?",
                   (rec.diagnosis, rec.medical_history, pid))

    def add_test(self, patient_id, name, test_date, result=""):
        t = MedicalTest(None, self.patients[patient_id], name, test_date, result)
        return self._exec("INSERT INTO tests(patient_id,name,test_date,result) VALUES(?,?,?,?)",
                          (patient_id, t.test_name, t.test_date.isoformat(), t.result))

    def set_test_result(self, tid, result):
        t = self.tests[tid]
        t.update_result(result)
        self._exec("UPDATE tests SET result=? WHERE id=?", (t.result, tid))

    # ----------------------------------------------------------- Назначения
    def add_prescription(self, patient_id, doctor_id, medication, dosage, duration):
        pr = Prescription(None, self.patients[patient_id], self.doctors[doctor_id],
                          medication, dosage, duration)
        return self._exec("INSERT INTO prescriptions(patient_id,doctor_id,medication,dosage,duration)"
                          " VALUES(?,?,?,?,?)",
                          (patient_id, doctor_id, pr.medication_name, pr.dosage, pr.duration))

    def update_prescription(self, prid, medication, dosage, duration):
        pr = self.prescriptions[prid]
        pr.update_prescription(medication, dosage, duration)
        self._exec("UPDATE prescriptions SET medication=?,dosage=?,duration=? WHERE id=?",
                   (pr.medication_name, pr.dosage, pr.duration, prid))

    # -------------------------------------------------------------- Оплаты
    def make_payment(self, patient_id, service_id=None, amount=None, discount=0):
        patient = self.patients[patient_id]
        service = self.services.get(service_id)
        discount = float(discount or 0)
        if amount in (None, ""):
            if not service:
                raise ValidationError("Выберите услугу или укажите сумму")
            amount = service.calculate_price(1, discount)
        desc = service.name if service else "Оплата услуг"
        pay = Payment(None, patient, amount, description=desc)
        pay.make_payment()
        return self._exec("INSERT INTO payments(patient_id,amount,payment_date,status,description)"
                          " VALUES(?,?,?,?,?)",
                          (patient_id, pay.amount, pay.payment_date.isoformat(timespec="seconds"),
                           pay.status.value, desc))

    def refund_payment(self, pay_id):
        p = self.payments[pay_id]
        p.refund_payment()
        self._exec("UPDATE payments SET status=? WHERE id=?", (p.status.value, pay_id))

    # ----------------------------------------------------------- Статистика
    def statistics(self):
        appts = list(self.appointments.values())
        return {
            "patients": len(self.patients),
            "doctors": len(self.doctors),
            "appointments": len(appts),
            "completed": sum(a.status == AppointmentStatus.Completed for a in appts),
            "cancelled": sum(a.status == AppointmentStatus.Cancelled for a in appts),
            "active": sum(a.status in (AppointmentStatus.Scheduled, AppointmentStatus.Confirmed)
                          for a in appts),
            "paid_total": sum(p.calculate_payment() for p in self.payments.values()),
            "refunded_total": sum(p.amount for p in self.payments.values()
                                  if p.status == PaymentStatus.Refunded),
            "payroll": sum(d.calculate_payment() for d in self.doctors.values()),
        }

    # ------------------------------------------------------------ Демо-данные
    def seed_demo(self):
        if self.patients or self.doctors:
            return
        d1 = self.add_doctor("Иванов Сергей Петрович", "1978-04-12", "Терапевт", 18, "101", 90000)
        d2 = self.add_doctor("Ахметова Дана Маратовна", "1985-09-30", "Кардиолог", 11, "205", 110000)
        d3 = self.add_doctor("Смирнова Елена Викторовна", "1990-01-21", "Невролог", 6, "310", 100000)
        dep1 = self.add_department("Терапевтическое отделение", 1, "+7 (700) 111-22-33", d1)
        dep2 = self.add_department("Кардиология", 2, "+7 (700) 222-33-44", d2)
        self.load()
        self.department_add_doctor(dep1, d1)
        self.department_add_doctor(dep2, d2)
        s1 = self.add_service("Первичный приём терапевта", "Осмотр и консультация", 8000, 30)
        s2 = self.add_service("ЭКГ", "Электрокардиография", 5000, 30)
        s3 = self.add_service("Консультация невролога", "Приём и рекомендации", 12000, 60)
        p1 = self.add_patient("Нурланов Алихан Ермекович", "1992-06-15", "+7 701 555-10-20",
                              "alikhan@example.com", "г. Кызылорда, ул. Абая 10")
        p2 = self.add_patient("Петрова Мария Игоревна", "1980-11-02", "+7 702 444-30-40",
                              "maria@example.com", "г. Кызылорда, ул. Жибек Жолы 5")
        self.load()
        self.update_record(p1, "Гипертоническая болезнь I ст.", "Первичное обращение, жалобы на давление")
        a1 = self.create_appointment(p1, d2, date.today().isoformat(), "10:00", s2)
        a2 = self.create_appointment(p2, d1, date.today().isoformat(), "11:30", s1)
        self.load()
        self.change_appointment(a1, "confirm")
        self.change_appointment(a2, "confirm")
        self.change_appointment(a2, "complete")
        self.add_test(p1, "Общий анализ крови", date.today().isoformat(), "Норма")
        self.add_prescription(p1, d2, "Лизиноприл", "10 мг 1 раз в день", "30 дней")
        self.make_payment(p2, s1)
