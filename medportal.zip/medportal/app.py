"""Веб-интерфейс «Медицинского портала» (замена консольного меню, задача 25).
Запуск:  python app.py   →   http://localhost:5000
"""
import os
from datetime import date

from flask import Flask, flash, g, redirect, render_template, request, url_for

from models import AppointmentStatus, PaymentStatus, ValidationError, work_slots
from portal import MedicalPortal

app = Flask(__name__)
app.secret_key = "medical-portal-local-dev"

MenuInfo = [
    ("Добавить пациента", "patients", "1"), ("Добавить врача", "doctors", "2"),
    ("Все пациенты", "patients", "3"), ("Все врачи", "doctors", "4"),
    ("Записать на приём / отменить", "appointments", "5–6"),
    ("Расписание врача", "doctors", "7"), ("Медицинские анализы", "tests", "8"),
    ("Медицинские назначения", "prescriptions", "9"), ("Оплата услуг", "payments", "10"),
    ("Поиск пациента", "search", "11"), ("Статистика", "stats", "12"),
]


def portal():
    if "portal" not in g:
        g.portal = MedicalPortal()
    return g.portal


@app.context_processor
def inject():
    return {"AppointmentStatus": AppointmentStatus, "PaymentStatus": PaymentStatus,
            "today": date.today().isoformat(), "slots": work_slots()}


def run(action, ok_msg, back, *args, **kw):
    """Выполнить операцию, показать сообщение об успехе/ошибке и вернуться."""
    try:
        res = action(*args, **kw)
        if ok_msg:
            flash(ok_msg, "ok")
        return res, True
    except ValidationError as e:
        flash(str(e), "err")
    except (KeyError, ValueError) as e:
        flash(f"Ошибка данных: {e}", "err")
    return None, False


def back(default="index"):
    return redirect(request.referrer or url_for(default))


def f(name):
    return request.form.get(name, "")


def fid(name):
    v = request.form.get(name, "")
    return int(v) if v.isdigit() else None


# ------------------------------------------------------------------ Главная
@app.route("/")
def index():
    p = portal()
    upcoming = sorted((a for a in p.appointments.values()
                       if a.status in (AppointmentStatus.Scheduled, AppointmentStatus.Confirmed)),
                      key=lambda a: a.date_time)[:6]
    return render_template("index.html", s=p.statistics(), upcoming=upcoming, menu=MenuInfo)


# ----------------------------------------------------------------- Пациенты
@app.route("/patients")
def patients():
    return render_template("patients.html", patients=portal().patients.values())


@app.post("/patients/add")
def patient_add():
    res, ok = run(portal().add_patient, "Пациент добавлен", None, f("full_name"), f("birth_date"),
                  f("phone"), f("email"), f("address"))
    return redirect(url_for("patient_detail", pid=res)) if ok else back("patients")


@app.route("/patients/<int:pid>")
def patient_detail(pid):
    p = portal()
    if pid not in p.patients:
        flash("Пациент не найден", "err")
        return redirect(url_for("patients"))
    return render_template("patient_detail.html", pt=p.patients[pid], p=p)


@app.post("/patients/<int:pid>/update")
def patient_update(pid):
    run(portal().update_patient, "Профиль обновлён", None, pid, full_name=f("full_name"),
        birth_date=f("birth_date"), phone=f("phone"), email=f("email"), address=f("address"))
    return back()


@app.post("/patients/<int:pid>/record")
def patient_record(pid):
    run(portal().update_record, "Медицинская карта обновлена", None, pid,
        diagnosis=f("diagnosis").strip() or None, history_note=f("history_note").strip() or None)
    return back()


@app.post("/patients/<int:pid>/delete")
def patient_delete(pid):
    run(portal().delete_patient, "Пациент и его медицинская карта удалены", None, pid)
    return redirect(url_for("patients"))


@app.route("/search")
def search():
    q = request.args.get("q")
    results, error = None, None
    if q is not None:
        try:
            results = portal().search_patients(q)
        except ValidationError as e:
            error = str(e)
    return render_template("search.html", q=q or "", results=results, error=error)


# -------------------------------------------------------------------- Врачи
@app.route("/doctors")
def doctors():
    return render_template("doctors.html", doctors=portal().doctors.values(),
                           departments=portal().departments.values())


@app.post("/doctors/add")
def doctor_add():
    run(portal().add_doctor, "Врач добавлен", None, f("full_name"), f("birth_date"),
        f("specialization"), f("experience"), f("cabinet"), f("salary"), fid("department_id"))
    return back("doctors")


@app.route("/doctors/<int:did>")
def doctor_detail(did):
    p = portal()
    if did not in p.doctors:
        flash("Врач не найден", "err")
        return redirect(url_for("doctors"))
    try:
        day = date.fromisoformat(request.args.get("date", date.today().isoformat()))
    except ValueError:
        day = date.today()
    d = p.doctors[did]
    return render_template("doctor_detail.html", d=d, day=day, free=d.free_slots(day),
                           day_appts=d.appointments_on(day), p=p)


@app.post("/doctors/<int:did>/specialization")
def doctor_spec(did):
    run(portal().update_specialization, "Специализация обновлена", None, did, f("specialization"))
    return back()


# --------------------------------------------------------------- Отделения
@app.route("/departments")
def departments():
    p = portal()
    return render_template("departments.html", departments=p.departments.values(),
                           doctors=p.doctors.values())


@app.post("/departments/add")
def department_add():
    run(portal().add_department, "Отделение добавлено", None, f("name"), f("floor"), f("phone"))
    return back("departments")


@app.post("/departments/<int:dep>/add_doctor")
def department_add_doctor(dep):
    run(portal().department_add_doctor, "Врач добавлен в отделение", None, dep, fid("doctor_id"))
    return back()


@app.post("/departments/<int:dep>/remove_doctor/<int:did>")
def department_remove_doctor(dep, did):
    run(portal().department_remove_doctor, "Врач убран из отделения (сам врач сохранён)", None, dep, did)
    return back()


@app.post("/departments/<int:dep>/head/<int:did>")
def department_head(dep, did):
    run(portal().set_head_doctor, "Заведующий назначен", None, dep, did)
    return back()


# ------------------------------------------------------------------- Услуги
@app.route("/services")
def services():
    return render_template("services.html", services=portal().services.values())


@app.post("/services/add")
def service_add():
    run(portal().add_service, "Услуга добавлена", None, f("name"), f("description"),
        f("price"), f("duration"))
    return back("services")


@app.post("/services/<int:sid>/price")
def service_price(sid):
    run(portal().update_service_price, "Стоимость обновлена", None, sid, f("price"))
    return back()


# -------------------------------------------------------------------- Приёмы
@app.route("/appointments")
def appointments():
    p = portal()
    items = sorted(p.appointments.values(), key=lambda a: a.date_time, reverse=True)
    return render_template("appointments.html", items=items, p=p,
                           sel_doctor=request.args.get("doctor", type=int),
                           sel_patient=request.args.get("patient", type=int))


@app.post("/appointments/add")
def appointment_add():
    run(portal().create_appointment, "Пациент записан на приём", None, fid("patient_id"),
        fid("doctor_id"), f("date"), f("time"), fid("service_id"))
    return back("appointments")


@app.post("/appointments/<int:aid>/<action>")
def appointment_action(aid, action):
    if action not in ("confirm", "cancel", "complete"):
        return "Неизвестное действие", 404
    msgs = {"confirm": "Приём подтверждён", "cancel": "Запись отменена", "complete": "Приём завершён"}
    run(portal().change_appointment, msgs[action], None, aid, action)
    return back()


# ------------------------------------------------- Анализы и назначения
@app.route("/tests")
def tests():
    p = portal()
    return render_template("tests.html", tests=p.tests.values(), patients=p.patients.values())


@app.post("/tests/add")
def test_add():
    run(portal().add_test, "Анализ добавлен", None, fid("patient_id"), f("name"),
        f("test_date"), f("result"))
    return back("tests")


@app.post("/tests/<int:tid>/result")
def test_result(tid):
    run(portal().set_test_result, "Результат сохранён", None, tid, f("result"))
    return back()


@app.route("/prescriptions")
def prescriptions():
    p = portal()
    return render_template("prescriptions.html", items=p.prescriptions.values(),
                           patients=p.patients.values(), doctors=p.doctors.values())


@app.post("/prescriptions/add")
def prescription_add():
    run(portal().add_prescription, "Назначение создано", None, fid("patient_id"),
        fid("doctor_id"), f("medication"), f("dosage"), f("duration"))
    return back("prescriptions")


@app.post("/prescriptions/<int:prid>/update")
def prescription_update(prid):
    run(portal().update_prescription, "Назначение обновлено", None, prid,
        f("medication"), f("dosage"), f("duration"))
    return back()


# -------------------------------------------------------------------- Оплаты
@app.route("/payments")
def payments():
    p = portal()
    return render_template("payments.html", items=sorted(p.payments.values(), key=lambda x: -x.id),
                           patients=p.patients.values(), services=p.services.values())


@app.post("/payments/add")
def payment_add():
    run(portal().make_payment, "Оплата принята", None, fid("patient_id"), fid("service_id"),
        f("amount"), f("discount") or 0)
    return back("payments")


@app.post("/payments/<int:pid>/refund")
def payment_refund(pid):
    run(portal().refund_payment, "Средства возвращены", None, pid)
    return back()


# ---------------------------------------------------- Статистика, UML, отчёт
@app.route("/stats")
def stats():
    return render_template("stats.html", s=portal().statistics())


@app.route("/uml")
def uml():
    svg_path = os.path.join(app.static_folder, "uml.svg")
    svg = open(svg_path, encoding="utf-8").read() if os.path.exists(svg_path) else None
    return render_template("uml.html", svg=svg)


@app.route("/report")
def report():
    return render_template("report.html")


if __name__ == "__main__":
    MedicalPortal().seed_demo()
    app.run(host="127.0.0.1", port=5000, debug=False)
